from  contextlib import closing
import sqlite3
class ProductsClass:
    def __init__(self,dbName):
        self.dbName=dbName
    
    def bdCreate(self,conn):
        cursorObj=conn.cursor()
        cursorObj.execute('''
          table if not exist 
                          Products(prodId integer,name text,qty integer,price integer,primary key(prodId)
                          ''')

    def dbInsert(self,conn):
        n=int(input("enter the record :")) 
        for i in range(n):
            prodId=int(input("enter prodId :"))
            name=input('enter name: ')
            qty=int(input("enter quantity :"))
            price=int(input("enter price :"))
            entities=(prodId,name,qty,price)
        cursorObj=conn.cursor()

    def dbDisplayAll(self,conn):
        cursorObj=conn.cursor()
        cursorObj.execute("select * from Products")
        rs=cursorObj.fetchall()
        for row in rs:
            print(row[0])
    def dbDelete(self,conn):
        prodId=int(input("enter id prodId :"))
        cursorObj=conn.cursor()
        sqlStr="delete from Products where prodId=?"
        cursorObj.execute(sqlStr,(prodId,))
        conn.commite()

    def dbUpdate(self,conn):
        cursorObj=conn.cursor()
        cursorObj.execute("update Products SET price=price*0.1 where  price<50")

def main():
    conn=sqlite3.connect("database.db")
    ProductsClass(conn)
if __name__ =="__main__":
    main()