# import tkinter as tk
# from tkinter import ttk
# # def clear(self):
#     # print("Intrest rate=",self.monthlyInvestment.get())
# #   self.monthlyInvestment.set("")
# class intrest(ttk.Frame):
#     def __init__(self,parent):
#       ttk.Frame.__init__(self,parent,padding="10 20 10 10")
#       self.pack(fill=tk.BOTH,expand=True)
#       self.monthlyInvestment=tk.StringVar()
#       ttk.Label(self,text="INTREST CALCULATOR").grid(column=0,row=0,sticky=tk.E)
#       ttk.Entry(self,width="30",textvariable=self.monthlyInvestment).grid(column=1,row=0)
#       ttk.Button(self,text="ok",command=self.destroy()).grid(column=2,row=0)

# if __name__ == "__main__":  
   
#    root=tk.Tk()
#    root.title("Calcuator")
#    root.geometry("200x200") 
# #    frame=ttk.Frame
#    intrest(root)
#    root.mainloop()
   
import tkinter as tk

class RestaurantBillManagement:
   def __init__(self):
      self.menu = {
            "Pizza": 10,
            "Burger": 5,
            "Pasta": 8,
            "Salad": 6,
            "Soft Drink": 2
                  }
        self.order_items = {}
        self.total_amount = 0
        self.root = tk.Tk()
        self.root.title("Restaurant Bill Management System")
        self.create_gui()
    def create_gui(self):
# Labels
      tk.Label(self.root, text="Menu").grid(row=0, column=0, padx=10, pady=5)
      tk.Label(self.root, text="Quantity").grid(row=0, column=1, padx=10, pady=5)
      tk.Label(self.root, text="Price").grid(row=0, column=2, padx=10, pady=5)
# Menu items
      Row = 1
      for item, price in self.menu.items():
        tk.Label(self.root, text=item).grid(row=row, column=0)
        quanty_entry = tk.Entry(self.root)
        quanty_entry.grid(row=row, column=1)
        Price_label = tk.Label(self.root, text=f"Rs{price}")
        Price_label.grid(row=row, column=2)
Self.order_items[item] = {“quan􀆟ty”: quan􀆟ty_entry, “price”: price_label}
Row += 1
# Calculate total bu􀆩on
Tk.Bu􀆩on(self.root, text=”Calculate Total”, command=self.calculate_total).grid(row=row,
column=0, columnspan=3, pady=10)
# Reset bu􀆩on
Tk.Bu􀆩on(self.root, text=”Reset”, command=self.reset_order).grid(row=row+1, column=0,
pady=5)
# Print bu􀆩on
Tk.Bu􀆩on(self.root, text=”Print Bill”, command=self.print_bill).grid(row=row+1, column=1,
columnspan=2, pady=5)
# Total amount label
Row += 2
Tk.Label(self.root, text=”Total Amount: “).grid(row=row, column=0, padx=10, pady=5)
Self.total_amount_label = tk.Label(self.root, text=””)
Self.total_amount_label.grid(row=row, column=1, columnspan=2, padx=10, pady=5)
Def calculate_total(self):
Self.total_amount = 0
For item, data in self.order_items.items():
Quan􀆟ty = data[“quan􀆟ty”].get()
If quan􀆟ty.isdigit():
Price = int(quan􀆟ty) * self.menu[item]
Self.total_amount += price
Self.total_amount_label.config(text=f”Rs{self.total_amount}”)
Def reset_order(self):
For data in self.order_items.values():
Data[“quan􀆟ty”].delete(0, tk.END)
Self.total_amount = 0
Self.total_amount_label.config(text=””)
Def print_bill(self):
Bill_text = “Restaurant Bill\n”
Bill_text += “-----------------------------\n”
For item, data in self.order_items.items():
Quan􀆟ty = data[“quan􀆟ty”].get()
If quan􀆟ty.isdigit():
Quan􀆟ty = int(quan􀆟ty)
If quan􀆟ty > 0:
Price = quan􀆟ty * self.menu[item]
Bill_text += f”{item} x {quan􀆟ty} = rs{price}\n”
Bill_text += “-----------------------------\n”
Bill_text += f”Total Amount: ${self.total_amount}\n”
Print(bill_text)
Def run(self):
Self.root.mainloop()
If __name__ == “__main__”:
App = RestaurantBillManagement()
App.run()