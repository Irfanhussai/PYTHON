'''
Develop a menu driven program to implemnt a queue. The operations would be 
A. Add an item to the  queue
B. Delete an item from queue 
C. Display the Queue
'''
def AddQ(queue):
   print("\n")
   x=input("Enter THe ELements of Queue \t")
   queue.append(x)
   print("\n")
   print("ELEMENTS OF QUEUE ARE\t"+x)
print("\n")
def DelQ(queue):
  if len(queue)==0:
    print("EMPTY")
  else:
     print("\n") 
     x=queue.pop(0)
     print("Item:"+x+"is Deleted")
def DispQ(queue):
    print("\n")
    print("\t \t Elements Of queue are")
    for item in queue:
       print(item)

def main():
   queue=[]
   while True:
    print("\n")
    choice=int(input("Enter Your Choice \n 1.ADD \t 2. DEL \t 3. DISP: \t"))
    if choice==1:
      AddQ(queue)
    elif choice==2:
        DelQ(queue)
    elif choice==3:
        DispQ(queue)
    else:
        break
if  __name__ == "__main__":
   main()
