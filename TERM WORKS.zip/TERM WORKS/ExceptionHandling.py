# VALUE ERROR EXCEPTION

'''
def getNum():
    try:
        n=int(input("Enter the integet")) 
        return n
    except ValueError:
        print("Enter the valid integer")
    
def getfloat():
   try:
      f=float(input("Enter the float number"))
      return f
   except ValueError:
      print("\n Unknown float number")
      
      
   '''
#OPERATING ERROR eXCEPTIONN 
''' fILE NOT FOUND'''


if __name__ == '__main__':
 x= getNum()
 y=getfloat()
#  print("You entered the no",x)
    # main()
    