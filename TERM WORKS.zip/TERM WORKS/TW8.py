'''
Experiment– 8 (NumPy, Pandas, Matplotlib) 
Problem Statement: Exam Score Analysis and Visualization
An exam has been conducted for a class of students. The exam data is stored in a CSV file,
Containing the student names and their scores.
Develop a Python program to analyse the exam scores, calculate key statistics, and
Visualize the data to gain insights into the students’ performance.

'''

# Importing required libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import csv
'''
'''

# Step 1: Load the exam data using Pandas
# def load_exam_data():
#     return pd.read_csv('ExamScores.csv')
# Step 2: Calculate key statistics using Numpy
def calculate_statistics(data):
    # Calculating average score
    Average_score = np.mean(data['score'])
    # Calculating maximum and minimum scores
    Max_score = np.max(data['score'])
    Min_score = np.min(data['score'])
    # Calculating number of students
    Num_students = len(data)
    return Average_score, Max_score, Min_score, Num_students

# Step 3: Visualize the exam scores using matplotlib
def create_visualizations(data):
    # Histogram of exam scores
    plt.figure(figsize=(4, 2))
    plt.hist(data['score'], bins=10, edgecolor='black')
    plt.xlabel('score')
    plt.ylabel('Frequency')
    plt.title('Exam Score Distribution')
    plt.show()

    # Bar chart for top-performing students
    Top_students = data[data['score'] >= 90]
    plt.figure(figsize=(4, 4))
    plt.bar(Top_students['name'], Top_students['score'], color='green')
    plt.xlabel('Student Name')
    plt.ylabel('score')
    plt.title('Top-performing Students')
#     plt.xticks(rotation=9)
    plt.show()

# Main function to execute the program
def main():
    # Step 1: Load the exam data
    Exam_data=pd.read_csv("ExamScore.csv")

    # Step 2: Calculate key statistics
    Avg_score, max_score, min_score, num_students = calculate_statistics(Exam_data)
    print("Average Score:", Avg_score)
    print("Maximum Score:", max_score)
    print("Minimum Score:", min_score)
    print("Number of Students:", num_students)
    create_visualizations(Exam_data)

if __name__ == "__main__":
    main()
