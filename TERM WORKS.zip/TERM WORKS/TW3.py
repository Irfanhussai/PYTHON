import csv
def searchBkAuthor():
    author = input("Enter author name:")
    with open("TW3.csv") as outfile:
        reader = csv.reader(outfile)
        result = []
        for row in reader:
            if row[2] == author:
                result.append(row)
        if result == []:
            print("No book found")
        else:
            print("Books with the specified author are...")
        for line in result:
            print(line)
def searchBkPrice():
    price=input("Enter Book price")
    with open("TW3.csv") as outfile:
        reader=csv.reader(outfile)
        result=[]
        for row in reader:
            if row[3]<=price:
                result.append(row)
        if result ==[]:
            print("No book Found")
        else:
            print("Books with the specified price are...")
        for line in result:
            print(line)
     
def searchBkTitle():
    word=input("Enter Word:")
    with open("TW3.csv") as outfile:
        reader=csv.reader(outfile)
        result=[]
        for row in reader:
            lstTitle=row[1].split()
            if(word in lstTitle):
                result.append(lstTitle)
        if result==[]:
            print("No book found")
        else:
            print("Books with specified word are...")
        for line in result:
            print(line)    
            
def readSaveBookInfo():
    bookLst=[]
    while True:
        bookNo = input("Enter book num:")
        title = input("Enter book title: ")
        author = input("Enter book author: ")
        price = int(input("Enter book price:"))
        price = int(price)
        bookLst.append([bookNo, title,author, price])
        ch = input("Enter Y/N to enter more:")
        if(ch.upper() == "N"):
            with open("TW3.csv","a")as outfile:
                writer = csv.writer(outfile,lineterminator = "\n")
                writer.writerows(bookLst)
                print("Item added")
            break
def main():
    readSaveBookInfo()
    menuDict = {1:searchBkAuthor, 2:searchBkPrice, 3:searchBkTitle, 4:"Exit" }
    while True:
        print("1.SEARCH BOOK BY AUTHOR \t 2.SEARCH BOOK BY PRICE \t 3.1.SEARCH BOOK BY TITLE \t 4. EXIT")
        choice = int(input("Enter choice:" ))
        if choice == 4:
            break
        menuDict[choice]()
if __name__ == "__main__":
    main()