class customer:
    def __init__(self,name,email):
        self.name=name
        self.email=email
        self.orders=[]


    def place_order(self,order):
        self.orders.append(order)

    def get_orders(self):
        return self.orders
        
    def get_name(self):
        return self.name
    def get_email(self):
        return self.email

class order:
    def __init__(self,order_id,products) :
        self.order_id=order_id
        self.products=products
    def get_order_id(self):
        return self.order_id
    
    def get_total_price(self):
        total_price=0
        for product in self.products:
            total_price+=product.get_price()
        return total_price
    
class product:
    def __init__(self,name,price):
        self.name=name
        self.price=price

    def get_name(self):
        return self.name
    
    def get_price(self):
        return self .price
    

def main():
    customer1=customer("suraj","suraj@123")
    # customer2=customer("Irfan","irfan@!23")

    product1=product("samsung",500)
    product2=product("Apple",25000)

    order1=order(1,[product1,product2])
    order2=order(2,[product1])
    customer1.place_order(order1)
    customer1.place_order(order2)
    
    # printing order

    print(customer1.name)
    orders=customer1.get_orders()

    for ord in orders :
        print(f"\n\nOrder Id : {ord.get_order_id()}")
        print("Products are : ")
        for prd in ord.products :
            print(f"Product name : {prd.get_name()} Price : {prd.get_price()}")

        print(f"Total Price {ord.get_total_price()}")


        # for prod 

    # for ord in orders:
    #     for prod in ord:
    #         print(prod.get_name(), prod.get_price())

    #     print(ord.get_total_price())



if __name__ == "__main__":
    main()
    