import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
class Calculator(ttk.Frame):
    def __init__(self,parent):
        ttk.Frame.__init__(self,parent,padding="10 10 10 10")
        self.pack(fill=tk.BOTH,expand=True)
        x=tk.IntVar()
        y=tk.IntVar()
        z=tk.IntVar()

        ttk.Label(self,width="20",text="Enter the number 1",background="green").grid(column=0,row=0,sticky=tk.E,padx=5,pady=5)
        ttk.Entry(self,width="10",textvariable=x,background="white").grid(column=1,row=0,sticky=tk.E,padx=5,pady=5) 
        
        ttk.Label(self,width="20",text="Enter the number 2",background="green").grid(column=0,row=1,sticky=tk.E,padx=5,pady=5)
        ttk.Entry(self,width="10",textvariable=y).grid(column=1,row=1,sticky=tk.E,padx=5,pady=5)

        ttk.Label(self,width="20",text="Result=:",background="Red").grid(column=0,row=2,sticky=tk.E,padx=5,pady=5)
        ttk.Entry(self,width="10",textvariable=z,state="disabled").grid(column=1,row=2,sticky=tk.E,padx=5,pady=5)
        def validInput():
              num1=x.get()
              num2=y.get()
              if not num1 or not num2:
                    return False
              else:
                    return True  
        def add():
                #  if not x.get() or not y.get():
                if not validInput():
                        messagebox.showerror('message',"Enter the valid input")
                
                sum=x.get()+y.get()
                z.set(sum)                     
        ttk.Button(self,text="Add",command=add).grid(column=0,row=3,sticky=tk.E,padx=5,pady=5)
        
        def sub():
                 sum=x.get()-y.get()
                 z.set(sum)                      
        ttk.Button(self,text="Sub",command=sub).grid(column=1,row=3,sticky=tk.E,padx=5,pady=5)
        
        def Mul():
                 sum=x.get()*y.get()
                 z.set(sum)                     
        ttk.Button(self,text="Prod",command=Mul).grid(column=2,row=3,sticky=tk.E)

        def  Div():
                 sum=x.get()/y.get()
                 z.set(sum)                     
        ttk.Button(self,text="Div",command=Div).grid(column=3,row=3,sticky=tk.E)

        
if __name__ =="__main__": 
    root=tk.Tk()
    root.geometry("500x500")
    root.title("Clculator")
    Calculator(root)
    root.mainloop()